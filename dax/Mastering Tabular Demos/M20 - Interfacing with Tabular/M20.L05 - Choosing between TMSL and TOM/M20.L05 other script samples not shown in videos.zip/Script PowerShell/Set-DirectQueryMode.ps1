﻿param (
    [ValidateNotNullOrEmpty()][string]$ssasInstanceName,
    [ValidateNotNullOrEmpty()][string]$databaseName,
    [ValidateSet('Import','DirectQuery')][string]$defaultMode="" )
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices.Tabular")
$svr = new-Object Microsoft.AnalysisServices.Tabular.Server
$svr.Connect($ssasInstanceName)
$database = $svr.databases
$db = $database.GetByName($databaseName)
$db.Model.DefaultMode = $defaultMode
$db.Model.SaveChanges()

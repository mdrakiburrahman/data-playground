﻿[System.Reflection.Assembly]::LoadWithPartialName( "Microsoft.AnalysisServices.Tabular" )
# Set Verbose to 0 if you do not want to see the verbose log
$verbose = 1

function GetPartitionNumber ( [int]$year, [int]$month ) {
    $year * 12 - 1 + $month
}

function GetPartitionYear ( $partitionNumber ) {
    [int][math]::floor( $partitionNumber / 12 )
}

function GetPartitionMonth ( $partitionNumber ) {
    [int]( ( $partitionNumber ) % 12 + 1 )
}

function GetPartitionStart ( $partitionNumber ) {
    $year = GetPartitionYear ( $partitionNumber )
    $month = GetPartitionMonth ( $partitionNumber ) 
    ( New-Object DateTime( $year, $month, 1 ) )
}

function GetPartitionEnd ( $partitionNumber ) {
    $year = GetPartitionYear ( $partitionNumber )
    $month = GetPartitionMonth ( $partitionNumber ) 
    ( New-Object DateTime( $year, $month, 1 ) ).AddMonths( 1 ).AddDays( -1 )
}

function GetPartitionName ( $partitionNumber ) {
    $year = GetPartitionYear ( $partitionNumber )
    $month = GetPartitionMonth ( $partitionNumber ) 
    ( New-Object DateTime( $year, $month, 1 ) ).ToString( "yyyyMM" )
}

function AddPartition( $table, $referencePartition, [int]$partitionNumber ) {
    $partitionStart = GetPartitionStart ( $partitionNumber )
    $partitionEnd = GetPartitionEnd ( $partitionNumber )
    $partitionName = GetPartitionName ( $partitionNumber )
    $existingPartition = $table.Partitions.Find( $partitionName )
    if ( !$existingPartition ) {
        if ( $verbose ) {
            "Add Partition " + $partitionName 
        }
        $placeHolder = "(1=0)"
        $newPartitionFilter = `
            "([Order Date] BETWEEN '" `
            + $partitionStart.ToString( "yyyyMMdd" ) `
            + "' AND '" + $partitionEnd.ToString( "yyyyMMdd" ) + "')"

        $newPartition = $referencePartition.Clone()
        $newPartition.Source.Query = $referencePartition.Source.Query.Replace( $placeHolder, $newPartitionFilter )
        # $newPartition.Source.Query
        $newPartition.Name = $partitionName
        $table.Partitions.Add( $newPartition )
    }
    else {
        if ( $verbose ) {
            "Existing Partition=" + $partitionName 
        }
    }
}

function ProcessPartition( $table, [int]$partitionNumber ) {
    $partitionName = GetPartitionName ( $partitionNumber )
    $existingPartition = $table.Partitions.Find( $partitionName )
    if ( !$existingPartition ) {
        if ( $verbose ) {
            "Partition not found: " + $partitionName
        }        
    }
    else {
        if ( $verbose ) {
            "Process table " + $table.Name + " partition " + $partitionName
        }
        $existingPartition.RequestRefresh( "DataOnly" )
    }
}


function RemovePartition( $table, [int]$partitionNumber ) {
    $partitionName = GetPartitionName ( $partitionNumber )
    $existingPartition = $table.Partitions.Find( $partitionName )
    if ( !$existingPartition ) {
        if ( $verbose ) {
            "Partition not found: " + $partitionName
        }
    }
    else {
        if ( $table.Partitions.Remove( $existingPartition ) ) {
            if ( $verbose ) {
                "Removing partition: " + $partitionName
            }
        }
        else {
            if ( $verbose ) {
                "Failed remove partition: " + $partitionName
            }
        }
    }
}

# ---------------------------------------------------
#   Parameters to process the monthly partitions
# ---------------------------------------------------


# Name of the server (including the instance name)
$serverName = "localhost\tabular"
# Name of the database 
$databaseName = "Dynamic Partitions"
# Name of the table that contains partitions
$tableName = "Sales"
# Name of the partition reference; it should contain (1=0) in the WHERE condition
$partitionReferenceName = "Sales" 
# Number of months/partitions to keep in memory
$monthsOnline = 18

# ---------------------------------------------------
#   Script to processes the monthly partitions
# ---------------------------------------------------

$server = New-Object Microsoft.AnalysisServices.Tabular.Server
$server.Connect( $serverName )
$db = $server.Databases[$databaseName]  
$model = $db.Model
$table = $model.Tables[$tableName]
$referencePartition = $table.Partitions[$partitionReferenceName] 


# Generates the range of partitions to process
$today = Get-Date
# NOTE: The sample database has data between 2007 and 2009.
#       By subtracting 8 years, any date in 2017 corresponds 
#       to dates in 2009. For this reason, we normalize the current
#       year so that it corresponds to the last year in the sample database.
#       You should remove the AddYears function for your database.
$currentDay = $today.AddYears( 2009 - $today.Year ) 
$lastPartition = $currentDay.Year * 12 - 1 + $currentDay.Month
$firstPartition = $lastPartition - $monthsOnline

# Removes the older partitions
ForEach ( $partitionScan in $table.Partitions ) {
    if ( $partitionScan.Name -ne $partitionReferenceName ) {
        $year = [math]::Floor( [int]( $partitionScan.Name ) / 100 )
        $month = [int]( $partitionScan.Name ) % 100
        $partitionNumber = GetPartitionNumber $year $month
        if ( ( $partitionNumber -lt $firstPartition ) `
             -or ( $partitionNumber -gt $lastPartition ) ) {
             RemovePartition $table $partitionNumber
        }
    }
}

# Adds the missing partitions
For ( $partitionNumber = $firstPartition; $partitionNumber -le $lastPartition; $partitionNumber++ ) {
    AddPartition $table $referencePartition $partitionNumber
}

# Processes the last two partitions
ProcessPartition $table ( $lastPartition - 1 )
ProcessPartition $table $lastPartition 

# Completes the refresh at the database level (also processes the new partitions)
$model.RequestRefresh( "Automatic" )
$model.SaveChanges()
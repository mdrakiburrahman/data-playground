﻿[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices.Tabular")

$server = New-Object Microsoft.AnalysisServices.Tabular.Server
$server.Connect("localhost\tab16")
$db = $server.Databases["Static Partitions"]
$model = $db.Model
$tableSales = $model.Tables["Sales"]
$tableProduct = $model.Tables["Product"]
$tableSales.RequestRefresh("Full")
$tableProduct.RequestRefresh("Full")
$model.SaveChanges()
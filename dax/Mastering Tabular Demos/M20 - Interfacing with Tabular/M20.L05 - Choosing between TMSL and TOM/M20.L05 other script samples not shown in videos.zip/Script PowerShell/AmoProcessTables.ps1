﻿[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices.Tabular")

$server = New-Object Microsoft.AnalysisServices.Tabular.Server
$server.Connect("localhost\tab16")
$db = $server.Databases["Contoso"]
$model = $db.Model
$tableProduct = $model.Tables["Product"]
$tableSales = $model.Tables["Sales"]
$tableProduct.RequestRefresh("DataOnly")
$tableSales.RequestRefresh("DataOnly")
$model.RequestRefresh("Calculate")
$saveOptions = New-Object Microsoft.AnalysisServices.Tabular.SaveOptions
$saveOptions.MaxParallelism = 5
$model.SaveChanges( $saveOptions )

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices.Tabular")
$server = New-Object Microsoft.AnalysisServices.Tabular.Server
$server.Connect("localhost\tabular")
foreach ( $db in $server.Databases ) {
    $db.Name
    foreach ( $table in $db.Model.Tables ) {
        "-->" + $table.Name
    }
}

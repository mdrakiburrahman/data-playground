﻿[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices.Tabular")

$server = New-Object Microsoft.AnalysisServices.Tabular.Server
$server.Connect("localhost\tab16")
$db = $server.Databases["Static Partitions"]
$model = $db.Model
$tableSales = $model.Tables["Sales"]
$partitionSales2009 = $tableSales.Partitions["Sales 2009"]
$partitionSales2009.RequestRefresh("Full")
$model.SaveChanges()
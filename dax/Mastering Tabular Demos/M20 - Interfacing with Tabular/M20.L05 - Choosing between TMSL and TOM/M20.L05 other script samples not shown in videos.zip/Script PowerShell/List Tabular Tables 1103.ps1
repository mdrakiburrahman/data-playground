[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices")
$server = New-Object Microsoft.AnalysisServices.Server
$server.Connect("localhost\tabular")
foreach ( $db in $server.Databases ) {
    $db.Name
    foreach ( $table in $db.Dimensions ) {
        "-->" + $table.Name
    }
}

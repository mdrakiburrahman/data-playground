[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices.Tabular")
$serverName = "localhost\tabular"
$dbName = "Contoso from BIM file"
$bimFilename = "c:\temp\model.bim"

$modelBim = [IO.File]::ReadAllText($bimFilename)
$db = Microsoft.AnalysisServices.Tabular.JsonSerializer]::DeserializeDatabase($modelBim)
$db.ID = $dbName
$db.Name = $dbName

$server = New-Object Microsoft.AnalysisServices.Tabular.Server
$server.Connect($serverName)

$server.Databases.Add( $db )
$db.Update( "ExpandFull" ) 

﻿[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices.Tabular")

$server = New-Object Microsoft.AnalysisServices.Tabular.Server
$server.Connect("localhost\tab16")
$db = $server.Databases["Static Partitions"]
$model = $db.Model
$model.RequestRefresh("Full")
$model.SaveChanges()
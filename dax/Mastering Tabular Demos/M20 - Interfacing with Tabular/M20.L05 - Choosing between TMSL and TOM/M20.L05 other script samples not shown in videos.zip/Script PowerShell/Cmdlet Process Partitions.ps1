﻿Invoke-ProcessPartition -Server "localhost\tab16" -Database "Partitions" -TableName "Sales" -PartitionName "Sales 2008" -RefreshType DataOnly
Invoke-ProcessPartition -Server "localhost\tab16" -Database "Partitions" -TableName "Sales" -PartitionName "Sales 2009" -RefreshType DataOnly
Invoke-ProcessASDatabase -Server "localhost\tab16" -DatabaseName "Partitions" -RefreshType Automatic





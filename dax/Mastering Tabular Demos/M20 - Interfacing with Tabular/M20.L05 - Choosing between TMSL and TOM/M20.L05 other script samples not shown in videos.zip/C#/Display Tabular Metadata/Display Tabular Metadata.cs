﻿using System;
using Microsoft.AnalysisServices.Tabular;

namespace Display_Tabular_Metadata {
    class Program {
        static void Main(string[] args) {
            Server server = new Server();
            server.Connect(@"localhost\tab16");

            ListDatabases(server);

            foreach (Database db1 in server.Databases) {
                if (db1.CompatibilityLevel >= 1200) {
                    ListMeasures(db1);
                    ListCalculatedColumns(db1);
                }
            }

            // Find a single database and display its measures and calculated columns
            Database db = server.Databases.FindByName("Contoso");
            if (db == null) {
                Console.WriteLine("Database not found");
                return;
            }
            if (db.CompatibilityLevel < 1200) {
                Console.WriteLine("Compatibility level {0} not supported", db.CompatibilityLevel);
                return;
            }
            ListMeasures(db);
            ListCalculatedColumns(db);
        }

        private static void ListCalculatedColumns(Database db) {
            Console.WriteLine("List of calculated columns in database {0} of server {1}", db.Name, db.Server.Name);
            foreach (Table t in db.Model.Tables) {
                foreach (Column c in t.Columns) {
                    CalculatedColumn cc = c as CalculatedColumn;
                    if (cc != null) {
                        Console.WriteLine("'{0}'[{1}] = {2} {3}", t.Name, cc.Name, cc.Expression, cc.IsHidden ? "[Hidden]" : "");
                    }
                }
            }
            Console.WriteLine();
        }

        private static void ListMeasures(Database db) {
            Console.WriteLine("List of measures in database {0} of server {1}", db.Name, db.Server.Name);
            foreach (Table t in db.Model.Tables) {
                foreach (Measure m in t.Measures) {
                    Console.WriteLine("'{0}'[{1}] = {2} {3}", t.Name, m.Name, m.Expression, m.IsHidden ? "[Hidden]" : "");
                }
            }
            Console.WriteLine();
        }

        private static void ListDatabases(Server server) {
            // List the databases on a server
            Console.WriteLine("Database (compatibility) - last process");
            foreach (Database db in server.Databases) {
                Console.WriteLine("{0} ({1}) - Process:{2}", db.Name, db.CompatibilityLevel, db.LastProcessed.ToString());
            }
            Console.WriteLine();
        }
    }
}

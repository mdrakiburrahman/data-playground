﻿using System;
using Microsoft.AnalysisServices.Tabular;

namespace CreateTabularDatabase {
    class Program {
        static Database NewSmallDb() {
            // Create the model and data source
            Model smallModel = new Model();
            smallModel.DataSources.Add(
                new ProviderDataSource() {
                    Name = "ContosoDW",
                    ConnectionString = @"Provider=SQLNCLI11;Data Source=localhost;" + 
                                       @"Initial Catalog=ContosoDW;Integrated Security=SSPI;" + 
                                       @"Persist Security Info=false",
                    ImpersonationMode = ImpersonationMode.ImpersonateServiceAccount
                });

            // Create columns for all the tables
            Column customerKey = new DataColumn {
                Name = "CustomerKey", SourceColumn = "CustomerKey", DataType = DataType.Int64 };
            Column customerName = new DataColumn {
                Name = "Name", SourceColumn = "Name", DataType = DataType.String };
            Column salesCustomerKey = new DataColumn {
                Name = "CustomerKey", SourceColumn = "CustomerKey", DataType = DataType.Int64 };
            Column salesDate = new DataColumn {
                Name = "Order Date", SourceColumn = "Order Date", DataType = DataType.DateTime };
            Column salesQuantity = new DataColumn {
                Name = "Quantity", SourceColumn = "Quantity", DataType = DataType.Int64 };
            Column salesUnitPrice = new DataColumn {
                Name = "Unit Price", SourceColumn = "Unit Price", DataType = DataType.Decimal };

            // Create tables
            Table tableCustomer = new Table {
                Name = "Customer",
                Columns = { customerKey, customerName },
                Partitions = {
                    new Partition {
                        Name = "Customer",
                        Source = new QueryPartitionSource() {
                            DataSource = smallModel.DataSources["ContosoDW"],
                            Query = @"SELECT [CustomerKey], [Name] FROM [Analytics].[Customer]"
                        }
                    }
                }
            };
            Table tableSales = new Table {
                Name = "Sales",
                Columns = { salesDate, salesCustomerKey, salesQuantity, salesUnitPrice },
                Measures = {
                    new Measure {
                        Name = "Sales Amount",
                        Expression = "SUMX ( Sales, Sales[Quantity] * Sales[Unit Price] )",
                        FormatString = "#,0.00"
                    }
                },
                Partitions = {
                    new Partition {
                        Name = "Sales",
                        Source = new QueryPartitionSource() {
                            DataSource = smallModel.DataSources["ContosoDW"],
                            Query = @"SELECT TOP (1000) [CustomerKey], [Order Date], " 
                                    + @"[Quantity], [Unit Price] FROM [Analytics].[Sales]"
                        }
                    }
                }
            };

            // Add tables and relationships to the data model
            smallModel.Tables.Add(tableCustomer);
            smallModel.Tables.Add(tableSales);
            smallModel.Relationships.Add(
                new SingleColumnRelationship {
                    FromColumn = salesCustomerKey,
                    FromCardinality = RelationshipEndCardinality.Many,
                    ToColumn = customerKey,
                    ToCardinality = RelationshipEndCardinality.One
                });

            // Create database
            Database smallContoso = new Database("Contoso Small");
            smallContoso.Model = smallModel;

            return smallContoso;
        }

        static void Main(string[] args) {
            // Create database metadata
            Database smallContoso = NewSmallDb();

            // Remove and create a new database using TOM
            // Connect to an existing server
            Server server = new Server();
            server.Connect(@"localhost\tabular");

            // Drop the existing database if it exists (we want to replace it completely)
            if (server.Databases.ContainsName(smallContoso.Name)) {
                Database existingDatabase = server.Databases[smallContoso.Name];
                existingDatabase.Drop();
            }
            
            // Add the new databases to the database collection
            server.Databases.Add(smallContoso);

            // Update the complete database metadata
            smallContoso.Update(Microsoft.AnalysisServices.UpdateOptions.ExpandFull,Microsoft.AnalysisServices.UpdateMode.CreateOrReplace);

            // Refresh the data in a new database
            smallContoso.Model.RequestRefresh(RefreshType.Full);
            smallContoso.Model.SaveChanges();


            // Generate and display the TMSL script
            // Note: We do not execute this TMSL. We use the TOM API instead, which 
            //       internally communicates by using a different protocol
            string tmsl = JsonScripter.ScriptCreateOrReplace(smallContoso);
            Console.WriteLine(tmsl);

        }
    }
}

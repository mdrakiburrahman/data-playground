﻿using System;
using Microsoft.AnalysisServices.Tabular;

namespace Generate_TMSL_Refresh {
    class Program {
        static void Main(string[] args) {
            Database dbContoso = new Database("Contoso");
            dbContoso.Model = new Model();
            Table tableSales = new Table { Name = "Sales" };
            Table tableCustomer = new Table { Name = "Customer" };
            dbContoso.Model.Tables.Add(tableSales);
            dbContoso.Model.Tables.Add(tableCustomer);
            string tmsl = JsonScripter.ScriptRefresh(
                new Table[] { tableSales, tableCustomer },
                RefreshType.Full);
            Console.WriteLine(tmsl);
        }
    }
}

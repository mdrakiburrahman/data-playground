﻿using System;
using System.IO;
using Microsoft.AnalysisServices.Tabular;
namespace DeployBimFile {
    class Program {
        static void Main(string[] args) {
            string serverName = @"localhost\tab16";
            string databaseName = "Contoso3";
            string bimFilename = @"k:\temp\model.bim";

            Console.WriteLine("Reading {0} file", bimFilename);
            Database database = ReadDatabaseFromBimFile(bimFilename);

            Console.WriteLine("Renaming database from {0} to {1}", database.Name, databaseName);
            database.Name = databaseName;
            database.ID = databaseName;

            Console.WriteLine("Connecting to {0}", serverName);
            Server server = new Server();
            server.Connect(serverName);

            Console.WriteLine("Deploying database {0}", database.Name);
            server.Databases.Add(database);
            database.Update(Microsoft.AnalysisServices.UpdateOptions.ExpandFull);
        }
        static Database ReadDatabaseFromBimFile(string path) {
            string modelBim = File.ReadAllText(path);
            Database database = JsonSerializer.DeserializeDatabase(modelBim);
            return database;
        }
        static void WriteDatabaseToBimFile(Database database, string path) {
            string modelBim = JsonSerializer.SerializeDatabase(database);
            File.WriteAllText(path, modelBim);
        }
    }
}

﻿using System;
using Microsoft.AnalysisServices.Tabular;

namespace AddMeasure {
    class Program {
        static void Main(string[] args) {
            string serverName = @"localhost\tabular";
            string databaseName = "Contoso";
            string tableName = "Sales";
            string measureName = "Total Sales";
            string measureExpression = "SUMX ( Sales, Sales[Quantity] * Sales[Net Price] )";

            string serverConnectionString = string.Format("Provider=MSOLAP;Data Source={0}", serverName);

            Server server = new Server();
            server.Connect(serverConnectionString);

            Database db = server.Databases[databaseName];
            Model model = db.Model;
            Table table = model.Tables[tableName];

            // Removes any previous calculated column named Rating
            // (this is just to repeat the test several times,
            //  this part of code is not included in the book)
            if (table.Measures.Find(measureName) != null) {
                Console.WriteLine("Removing measure");
                table.Measures.Remove(measureName);
                model.SaveChanges();
            }

            Console.WriteLine("Adding measure");
            table.Measures.Add(new Measure() { Name = measureName, Expression = measureExpression });
            model.SaveChanges();
        }
    }
}

﻿using System;
using Microsoft.AnalysisServices.Tabular;

namespace AddCalculatedColumn {
    class Program {
        static void Main(string[] args) {
            string serverName = @"localhost\tabular";
            string databaseName = "Contoso";
            string tableName = "Product";
            string columnName = "Rating";
            string measureExpression = 
                  "VAR CustomerRevenues = CALCULATE ( [Sales Amount] )"
                + "RETURN SWITCH ( TRUE(),"
                + "           CustomerRevenues >= 10000, \"A\","
                + "           CustomerRevenues >= 1000, \"B\","
                + "           \"C\""
                + "       )";

            Server server = new Server();
            server.Connect(serverName);
            Database db = server.Databases[databaseName];
            Table productTable = db.Model.Tables[tableName];

            // Removes any previous calculated column named Rating
            // (this is just to repeat the test several times,
            //  this part of code is not included in the book)
            if (productTable.Columns.Find(columnName) != null) {
                Console.WriteLine("Remove rating column");
                productTable.Columns.Remove(columnName);
                db.Model.SaveChanges();
            }

            Console.WriteLine("Creating rating column");
            productTable.Columns.Add(
                new CalculatedColumn {
                    Name = columnName,
                    Expression = measureExpression
                }
            );

            // Include an automatic refresh of the table
            productTable.RequestRefresh(RefreshType.Calculate);
            db.Model.SaveChanges();
        }
    }
}
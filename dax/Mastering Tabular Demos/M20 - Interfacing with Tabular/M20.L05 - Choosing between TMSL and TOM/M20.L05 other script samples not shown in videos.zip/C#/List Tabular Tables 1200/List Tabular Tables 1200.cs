﻿using System;
using Microsoft.AnalysisServices;
using Microsoft.AnalysisServices.Tabular;

namespace ListTables {
    class Program {
        static void Main(string[] args) {
            Server server = new Server();
            server.Connect(@"localhost\tabular");
            if (server.ServerMode == ServerMode.Tabular) {
                foreach (Database db in server.Databases) {
                    Console.WriteLine("{0}:{1}", db.ToString(), db.StorageEngineUsed);
                    if (db.StorageEngineUsed == StorageEngineUsed.TabularMetadata) {
                        foreach (Table d in db.Model.Tables) {
                            Console.WriteLine("--> {0}", d.Name);
                        }
                    }
                }
            }
            server.Disconnect();
        }
    }
}
